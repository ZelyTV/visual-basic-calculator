Imports System

Module Program
    Sub Main(args As String())
        Dim funct As String
        Dim value1, value2 As Double
        Dim repeat As Integer
        Console.WriteLine("pick a function (*, /, +, -)")
        funct = Console.ReadLine
        Console.WriteLine("create 2 values")
        value1 = Console.ReadLine
        value2 = Console.ReadLine
        repeat = 0
        If funct = "*" Then
            Console.WriteLine(value1 * value2)
        ElseIf funct = "/" Then
            Console.WriteLine(value1 / value2)
        ElseIf funct = "+" Then
            Console.WriteLine(value1 + value2)
        ElseIf funct = "-" Then
            Console.WriteLine(value1 - value2)
        Else
            Console.WriteLine("invalid argument, restart the program to try again")
        End If
        Console.ReadKey(True)
    End Sub
End Module
